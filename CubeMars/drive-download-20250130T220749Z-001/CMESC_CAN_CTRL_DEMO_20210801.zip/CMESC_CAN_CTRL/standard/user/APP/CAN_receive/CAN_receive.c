/**
  ****************************(C) COPYRIGHT 2016 DJI****************************
  * @file       can_receive.c/h
  * @brief      ���can�豸�����շ����������ļ���ͨ��can�ж���ɽ���
  * @note       ���ļ�����freeRTOS����
  * @history
  *  Version    Date            Author          Modification
  *  V1.0.0     Dec-26-2018     RM              1. ���
  *
  @verbatim
  ==============================================================================

  ==============================================================================
  @endverbatim
  ****************************(C) COPYRIGHT 2016 DJI****************************
  */

#include "CAN_Receive.h"

#include "stm32f4xx.h"
#include "rng.h"

#include "FreeRTOSConfig.h"
#include "FreeRTOS.h"
#include "task.h"

#include "Detect_Task.h"

//���̵�����ݶ�ȡ
#define get_motor_measure(ptr, rx_message)                                                     \
    {                                                                                          \
        (ptr)->last_ecd = (ptr)->ecd;                                                          \
        (ptr)->ecd = (uint16_t)((rx_message)->Data[0] << 8 | (rx_message)->Data[1]);           \
        (ptr)->speed_rpm = (uint16_t)((rx_message)->Data[2] << 8 | (rx_message)->Data[3]);     \
        (ptr)->given_current = (uint16_t)((rx_message)->Data[4] << 8 | (rx_message)->Data[5]); \
        (ptr)->temperate = (rx_message)->Data[6];                                              \
    }

//��̨������ݶ�ȡ
#define get_gimbal_motor_measuer(ptr, rx_message)                                              \
    {                                                                                          \
        (ptr)->last_ecd = (ptr)->ecd;                                                          \
        (ptr)->ecd = (uint16_t)((rx_message)->Data[0] << 8 | (rx_message)->Data[1]);           \
        (ptr)->given_current = (uint16_t)((rx_message)->Data[2] << 8 | (rx_message)->Data[3]); \
        (ptr)->speed_rpm = (uint16_t)((rx_message)->Data[4] << 8 | (rx_message)->Data[5]);     \
        (ptr)->temperate = (rx_message)->Data[6];                                              \
    }

//ͳһ����can���պ���
static void CAN_hook(CanRxMsg *rx_message);
//�����������
static motor_measure_t motor_yaw, motor_pit, motor_trigger, motor_chassis[4];

static CanTxMsg GIMBAL_TxMessage;

#if GIMBAL_MOTOR_6020_CAN_LOSE_SLOVE
static uint8_t delay_time = 100;
#endif
//can1�ж�
void CAN1_RX0_IRQHandler(void)
{
    static CanRxMsg rx1_message;

    if (CAN_GetITStatus(CAN1, CAN_IT_FMP0) != RESET)
    {
        CAN_ClearITPendingBit(CAN1, CAN_IT_FMP0);
        CAN_Receive(CAN1, CAN_FIFO0, &rx1_message);
        CAN_hook(&rx1_message);
    }
}

//can2�ж�
void CAN2_RX0_IRQHandler(void)
{
    static CanRxMsg rx2_message;
    if (CAN_GetITStatus(CAN2, CAN_IT_FMP0) != RESET)
    {
        CAN_ClearITPendingBit(CAN2, CAN_IT_FMP0);
        CAN_Receive(CAN2, CAN_FIFO0, &rx2_message);
        CAN_hook(&rx2_message);
    }
}

#if GIMBAL_MOTOR_6020_CAN_LOSE_SLOVE
void GIMBAL_lose_slove(void)
{
        delay_time = RNG_get_random_range(13,239);
}
#endif
//������̨�����������revΪ�����ֽ�
void CAN_CMD_GIMBAL(int16_t yaw, int16_t pitch, int16_t shoot, int16_t rev)
{
    GIMBAL_TxMessage.StdId = CAN_GIMBAL_ALL_ID;
    GIMBAL_TxMessage.IDE = CAN_ID_STD;
    GIMBAL_TxMessage.RTR = CAN_RTR_DATA;
    GIMBAL_TxMessage.DLC = 0x08;
    GIMBAL_TxMessage.Data[0] = (yaw >> 8);
    GIMBAL_TxMessage.Data[1] = yaw;
    GIMBAL_TxMessage.Data[2] = (pitch >> 8);
    GIMBAL_TxMessage.Data[3] = pitch;
    GIMBAL_TxMessage.Data[4] = (shoot >> 8);
    GIMBAL_TxMessage.Data[5] = shoot;
    GIMBAL_TxMessage.Data[6] = (rev >> 8);
    GIMBAL_TxMessage.Data[7] = rev;

#if GIMBAL_MOTOR_6020_CAN_LOSE_SLOVE

    TIM6->CNT = 0;
    TIM6->ARR = delay_time ;

    TIM_Cmd(TIM6,ENABLE);
#else
    CAN_Transmit( GIMBAL_CAN,  &GIMBAL_TxMessage );
#endif

}

void TIM6_DAC_IRQHandler(void)
{
    if( TIM_GetITStatus( TIM6, TIM_IT_Update )!= RESET )
    {

        TIM_ClearFlag( TIM6, TIM_IT_Update );
#if GIMBAL_MOTOR_6020_CAN_LOSE_SLOVE
        CAN_Transmit( GIMBAL_CAN,  &GIMBAL_TxMessage );
#endif
        TIM_Cmd(TIM6,DISABLE);
    }
}
//CAN ���� 0x700��ID�����ݣ�������M3508�����������IDģʽ
void CAN_CMD_CHASSIS_RESET_ID(void)
{

    CanTxMsg TxMessage;
    TxMessage.StdId = 0x700;
    TxMessage.IDE = CAN_ID_STD;
    TxMessage.RTR = CAN_RTR_DATA;
    TxMessage.DLC = 0x08;
    TxMessage.Data[0] = 0;
    TxMessage.Data[1] = 0;
    TxMessage.Data[2] = 0;
    TxMessage.Data[3] = 0;
    TxMessage.Data[4] = 0;
    TxMessage.Data[5] = 0;
    TxMessage.Data[6] = 0;
    TxMessage.Data[7] = 0;

    CAN_Transmit(CAN2, &TxMessage);
}

//���͵��̵����������
void CAN_CMD_CHASSIS(int16_t motor1, int16_t motor2, int16_t motor3, int16_t motor4)
{
    CanTxMsg TxMessage;
    TxMessage.StdId = CAN_CHASSIS_ALL_ID;
    TxMessage.IDE = CAN_ID_STD;
    TxMessage.RTR = CAN_RTR_DATA;
    TxMessage.DLC = 0x08;
    TxMessage.Data[0] = motor1 >> 8;
    TxMessage.Data[1] = motor1;
    TxMessage.Data[2] = motor2 >> 8;
    TxMessage.Data[3] = motor2;
    TxMessage.Data[4] = motor3 >> 8;
    TxMessage.Data[5] = motor3;
    TxMessage.Data[6] = motor4 >> 8;
    TxMessage.Data[7] = motor4;

    CAN_Transmit(CHASSIS_CAN, &TxMessage);
}
//����ZESC��������
void CAN_CMD_ZESC(int16_t cmd16, int16_t mode16, int32_t target_val)
{
    CanTxMsg TxMessage;
    TxMessage.StdId = 0x200;//CAN_ZESC_ID = 0x200,
    TxMessage.IDE = CAN_ID_STD;//CAN_Id_Standard
    TxMessage.RTR = CAN_RTR_DATA;
    TxMessage.DLC = 0x08;
    TxMessage.Data[0] = cmd16 >> 8;//	CAN_PACKET_SET_DUTY = 0,CAN_PACKET_SET_CURRENT=1,CAN_PACKET_SET_CURRENT_BRAKE=2,CAN_PACKET_SET_RPM=3,CAN_PACKET_SET_POS=4,
    TxMessage.Data[1] = cmd16;
    TxMessage.Data[2] = mode16 >> 8;//0-unlocked,1-locked
    TxMessage.Data[3] = mode16;
    TxMessage.Data[4] = target_val >> 24;//DUTY 0-10000,CURRENT -10000-10000,POS -1800-1800
    TxMessage.Data[5] = target_val >> 16;
    TxMessage.Data[6] = target_val >> 8;
    TxMessage.Data[7] = target_val;

    CAN_Transmit(CHASSIS_CAN, &TxMessage);
}
void CAN_CMD_ZESC_STD(int16_t mode, int16_t kp, int16_t kd, int16_t pos,int16_t spd,int16_t current,int16_t id)
{
    CanTxMsg TxMessage;
    TxMessage.StdId = id;
    TxMessage.IDE = CAN_ID_STD;
    TxMessage.RTR = CAN_RTR_DATA;
    TxMessage.DLC = 0x08;
		 
	  if(kp<0)kp=0;else if(kp>2000)kp=2000;
	  if(kd<0)kd=0;else if(kd>2000)kd=2000;
	  if(spd<-2047)spd=-2047;else if(spd>2047) spd=2047;spd=spd+2048;
	  if(current<-2047)current=-2047;else if(current>2047) current=2047;current=current+2048;
	
    TxMessage.Data[0] = (mode & 0X03) | (kp & 0x07E0)>>3;
    TxMessage.Data[1] = (kp & 0x001F) | (kd & 0x0700)>>3;
    TxMessage.Data[2] = (kd & 0x00FF);
    TxMessage.Data[3] = (pos&0xFF00)>>8;
    TxMessage.Data[4] = (pos&0x00FF);
    TxMessage.Data[5] = (spd & 0x0FF0)>>4;
    TxMessage.Data[6] = (spd & 0x000F) | (current & 0x0F00)>>4;
    TxMessage.Data[7] = (current & 0x00FF);

    CAN_Transmit(CHASSIS_CAN, &TxMessage);
}
void CAN_CMD_ZESC_SET_DJI()
{
    CanTxMsg TxMessage;
    TxMessage.StdId = 0x7FF;
    TxMessage.IDE = CAN_ID_STD;
    TxMessage.RTR = CAN_RTR_DATA;
    TxMessage.DLC = 0x08;
    TxMessage.Data[0] = 0xA1;
    TxMessage.Data[1] = 0xB2;
    TxMessage.Data[2] = 0xC3;
    TxMessage.Data[3] = 0xD4;
    TxMessage.Data[4] = 0xA1;
    TxMessage.Data[5] = 0xB2;
    TxMessage.Data[6] = 0xC3;
    TxMessage.Data[7] = 0xD4;

    CAN_Transmit(CHASSIS_CAN, &TxMessage);
}
void CAN_CMD_ZESC_SET_STD()
{
    CanTxMsg TxMessage;
    TxMessage.StdId = 0x7FF;
    TxMessage.IDE = CAN_ID_STD;
    TxMessage.RTR = CAN_RTR_DATA;
    TxMessage.DLC = 0x08;
    TxMessage.Data[0] = 0x1A;
    TxMessage.Data[1] = 0x2B;
    TxMessage.Data[2] = 0x3C;
    TxMessage.Data[3] = 0x4D;
    TxMessage.Data[4] = 0x1A;
    TxMessage.Data[5] = 0x2B;
    TxMessage.Data[6] = 0x3C;
    TxMessage.Data[7] = 0x4D;

    CAN_Transmit(CHASSIS_CAN, &TxMessage);
}
void CAN_CMD_ZESC_SET_DJI_ID(int16_t did)
{
    CanTxMsg TxMessage;
    TxMessage.StdId = 0x7FF;
    TxMessage.IDE = CAN_ID_STD;
    TxMessage.RTR = CAN_RTR_DATA;
    TxMessage.DLC = 0x08;
    TxMessage.Data[0] = 0xAA;
    TxMessage.Data[1] = 0xAA;
    TxMessage.Data[2] = 0xAA;
    TxMessage.Data[3] = (did >> 8)&0xff;
    TxMessage.Data[4] = did & 0xFF;
    TxMessage.Data[5] = 0xAA;
    TxMessage.Data[6] = 0xAA;
    TxMessage.Data[7] = 0xAA;

    CAN_Transmit(CHASSIS_CAN, &TxMessage);
}
void CAN_CMD_ZESC_SET_STD_ID(int16_t sid)
{
    CanTxMsg TxMessage;
    TxMessage.StdId = 0x7FF;
    TxMessage.IDE = CAN_ID_STD;
    TxMessage.RTR = CAN_RTR_DATA;
    TxMessage.DLC = 0x08;
    TxMessage.Data[0] = 0xBB;
    TxMessage.Data[1] = 0xBB;
    TxMessage.Data[2] = 0xBB;
    TxMessage.Data[3] = (sid >> 8)&0xff;
    TxMessage.Data[4] = sid & 0xFF;
    TxMessage.Data[5] = 0xBB;
    TxMessage.Data[6] = 0xBB;
    TxMessage.Data[7] = 0xBB;

    CAN_Transmit(CHASSIS_CAN, &TxMessage);
}
void CAN_CMD_ZESC_SET_ZERO()
{
    CanTxMsg TxMessage;
    TxMessage.StdId = 0x7FF;
    TxMessage.IDE = CAN_ID_STD;
    TxMessage.RTR = CAN_RTR_DATA;
    TxMessage.DLC = 0x08;
    TxMessage.Data[0] = 0xCC;
    TxMessage.Data[1] = 0xCC;
    TxMessage.Data[2] = 0xCC;
    TxMessage.Data[3] = 0xCC;
    TxMessage.Data[4] = 0xCC;
    TxMessage.Data[5] = 0xCC;
    TxMessage.Data[6] = 0xCC;
    TxMessage.Data[7] = 0xCC;

    CAN_Transmit(CHASSIS_CAN, &TxMessage);
}

void CAN_CMD_ZESC_SET_CAL()
{
    CanTxMsg TxMessage;
    TxMessage.StdId = 0x7FF;
    TxMessage.IDE = CAN_ID_STD;
    TxMessage.RTR = CAN_RTR_DATA;
    TxMessage.DLC = 0x08;
    TxMessage.Data[0] = 0xDD;
    TxMessage.Data[1] = 0xDD;
    TxMessage.Data[2] = 0xDD;
    TxMessage.Data[3] = 0xDD;
    TxMessage.Data[4] = 0xDD;
    TxMessage.Data[5] = 0xDD;
    TxMessage.Data[6] = 0xDD;
    TxMessage.Data[7] = 0xDD;

    CAN_Transmit(CHASSIS_CAN, &TxMessage);
}
void CAN_CMD_ZESC_GM(int16_t motor1, int16_t motor2, int16_t motor3, int16_t motor4)
{
    CanTxMsg TxMessage;
    TxMessage.StdId = 0x1FF;
    TxMessage.IDE = CAN_ID_STD;
    TxMessage.RTR = CAN_RTR_DATA;
    TxMessage.DLC = 0x08;
    TxMessage.Data[0] = motor1 >> 8;
    TxMessage.Data[1] = motor1;
    TxMessage.Data[2] = motor2 >> 8;
    TxMessage.Data[3] = motor2;
    TxMessage.Data[4] = motor3 >> 8;
    TxMessage.Data[5] = motor3;
    TxMessage.Data[6] = motor4 >> 8;
    TxMessage.Data[7] = motor4;

    CAN_Transmit(CHASSIS_CAN, &TxMessage);
}
void buffer_append_int32(uint8_t* buffer, int32_t number, int32_t *index) {
	buffer[(*index)++] = number >> 24;
	buffer[(*index)++] = number >> 16;
	buffer[(*index)++] = number >> 8;
	buffer[(*index)++] = number;
}

void comm_can_transmit_eid(uint32_t id, const uint8_t *data, uint8_t len) {
	uint8_t i=0;
	if (len > 8) {
		len = 8;
	}
  CanTxMsg TxMessage;
  TxMessage.StdId = 0;
	TxMessage.IDE = CAN_ID_EXT;
	TxMessage.ExtId = id;
	TxMessage.RTR = CAN_RTR_DATA;
	TxMessage.DLC = len;
	//memcpy(txmsg.data8, data, len);
	for(i=0;i<len;i++)
  TxMessage.Data[i]=data[i];

  CAN_Transmit(CHASSIS_CAN, &TxMessage);

}

void comm_can_set_duty(uint8_t controller_id, float duty) {//same as CMESC
	int32_t send_index = 0;
	uint8_t buffer[4];
	buffer_append_int32(buffer, (int32_t)(duty * 100000.0), &send_index);
	comm_can_transmit_eid(controller_id |
			((uint32_t)CAN_PACKET_SET_DUTY << 8), buffer, send_index);
}

void comm_can_set_current(uint8_t controller_id, float current) {//same as CMESC
	int32_t send_index = 0;
	uint8_t buffer[4];
	buffer_append_int32(buffer, (int32_t)(current * 1000.0), &send_index);
	comm_can_transmit_eid(controller_id |
			((uint32_t)CAN_PACKET_SET_CURRENT << 8), buffer, send_index);
}

void comm_can_set_current_brake(uint8_t controller_id, float current) {//same as CMESC
	int32_t send_index = 0;
	uint8_t buffer[4];
	buffer_append_int32(buffer, (int32_t)(current * 1000.0), &send_index);
	comm_can_transmit_eid(controller_id |
			((uint32_t)CAN_PACKET_SET_CURRENT_BRAKE << 8), buffer, send_index);
}

void comm_can_set_rpm(uint8_t controller_id, float rpm) {//same as CMESC
	int32_t send_index = 0;
	uint8_t buffer[4];
	buffer_append_int32(buffer, (int32_t)rpm, &send_index);
	comm_can_transmit_eid(controller_id |
			((uint32_t)CAN_PACKET_SET_RPM << 8), buffer, send_index);
}

void comm_can_set_pos(uint8_t controller_id, float pos) {//same as CMESC
	int32_t send_index = 0;
	uint8_t buffer[4];
	buffer_append_int32(buffer, (int32_t)(pos * 1000000.0), &send_index);
	comm_can_transmit_eid(controller_id |
			((uint32_t)CAN_PACKET_SET_POS << 8), buffer, send_index);
}

//void CAN_CMD_CMESC_STD(int16_t mode, int16_t kp, int16_t kd, int16_t pos,int16_t spd,int16_t current,uint8_t controller_id)
//{
//    CanTxMsg TxMessage;
//	  int32_t len=8;
//	  if(kp<0)kp=0;else if(kp>2000)kp=2000;
//	  if(kd<0)kd=0;else if(kd>2000)kd=2000;
//	  if(spd<-2047)spd=-2047;else if(spd>2047) spd=2047;spd=spd+2048;
//	  if(current<-2047)current=-2047;else if(current>2047) current=2047;current=current+2048;
//	
//    TxMessage.Data[0] = (mode & 0X03) | (kp & 0x07E0)>>3;
//    TxMessage.Data[1] = (kp & 0x001F) | (kd & 0x0700)>>3;
//    TxMessage.Data[2] = (kd & 0x00FF);
//    TxMessage.Data[3] = (pos&0xFF00)>>8;
//    TxMessage.Data[4] = (pos&0x00FF);
//    TxMessage.Data[5] = (spd & 0x0FF0)>>4;
//    TxMessage.Data[6] = (spd & 0x000F) | (current & 0x0F00)>>4;
//    TxMessage.Data[7] = (current & 0x00FF);
//	comm_can_transmit_eid(controller_id |
//			((uint32_t)CAN_PACKET_SET_ZESC << 8), TxMessage.Data,len);
//}


//����yaw���������ַ��ͨ��ָ�뷽ʽ��ȡԭʼ����
const motor_measure_t *get_Yaw_Gimbal_Motor_Measure_Point(void)
{
    return &motor_yaw;
}
//����pitch���������ַ��ͨ��ָ�뷽ʽ��ȡԭʼ����
const motor_measure_t *get_Pitch_Gimbal_Motor_Measure_Point(void)
{
    return &motor_pit;
}
//����trigger���������ַ��ͨ��ָ�뷽ʽ��ȡԭʼ����
const motor_measure_t *get_Trigger_Motor_Measure_Point(void)
{
    return &motor_trigger;
}
//���ص��̵��������ַ��ͨ��ָ�뷽ʽ��ȡԭʼ����
const motor_measure_t *get_Chassis_Motor_Measure_Point(uint8_t i)
{
    return &motor_chassis[(i & 0x03)];
}

//ͳһ����can�жϺ��������Ҽ�¼�������ݵ�ʱ�䣬��Ϊ�����ж�����
static void CAN_hook(CanRxMsg *rx_message)
{
    switch (rx_message->StdId)
    {
    case CAN_YAW_MOTOR_ID:
    {
        //����������ݺ꺯��
        get_gimbal_motor_measuer(&motor_yaw, rx_message);
        //��¼ʱ��
        DetectHook(YawGimbalMotorTOE);
        break;
    }
    case CAN_PIT_MOTOR_ID:
    {
        //����������ݺ꺯��
        get_gimbal_motor_measuer(&motor_pit, rx_message);
        DetectHook(PitchGimbalMotorTOE);
        break;
    }
    case CAN_TRIGGER_MOTOR_ID:
    {
        //����������ݺ꺯��
        get_motor_measure(&motor_trigger, rx_message);
        //��¼ʱ��
        DetectHook(TriggerMotorTOE);
        break;
    }
    case CAN_3508_M1_ID:
    case CAN_3508_M2_ID:
    case CAN_3508_M3_ID:
    case CAN_3508_M4_ID:
    {
        static uint8_t i = 0;
        //�������ID��
        i = rx_message->StdId - CAN_3508_M1_ID;
        //����������ݺ꺯��
        get_motor_measure(&motor_chassis[i], rx_message);
        //��¼ʱ��
        DetectHook(ChassisMotor1TOE + i);
        break;
    }

    default:
    {
        break;
    }
    }
}
