#ifndef USER_TASK_H
#define USER_TASK_H

extern void UserTask(void *pvParameters);

#endif
