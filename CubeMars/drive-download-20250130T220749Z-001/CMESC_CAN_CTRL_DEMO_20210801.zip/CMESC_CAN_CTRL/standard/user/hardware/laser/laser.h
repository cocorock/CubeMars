#ifndef LASER_H
#define LASER_H
#include "main.h"

extern void laser_configuration(void);
extern void laser_on(void);
extern void laser_off(void);
#endif
