#ifndef EXIT_INIT_H
#define EXIT_INIT_H
#include "main.h"

extern void GPIOB_Exti8_GPIO_Init(void);

#endif
