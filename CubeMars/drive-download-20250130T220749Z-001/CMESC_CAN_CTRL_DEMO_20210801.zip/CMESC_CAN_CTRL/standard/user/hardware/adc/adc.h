#ifndef ADC_H
#define ADC_H
#include "main.h"

extern void temperature_ADC_init(void);
extern fp32 get_temprate(void);
#endif
